<?php
    $hasSupply = $ingredients->contains(function ($ingredient) {
        return $ingredient->supplies->whereNull('stock_report_id')->isNotEmpty();
    });
?>

<?php $__env->startSection("content"); ?>
    <section>
        <div class="page-header">
            <div>
                <h1>Ingredients/Stocks</h1>
                <p>Manage your ingredients/stocks.</p>
            </div>
            
            <button class="btn-primary open-modal" data-modal="addModal">
                <i class="fa-solid fa-plus"></i>
                New Ingredient
            </button>
        </div>
        <div>
            <div class="card">
                <div class="toolbar">
                    <div class="search">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke-width="2">
                            <circle cx="11" cy="11" r="7" />
                            <path d="m21 21-4.3-4.3" />
                        </svg>
                        <input placeholder="Im looking for...">
                    </div>
                    
                    <div class="toolbar-right">
                        <button class="btn">Export</button>
                    </div>
                </div>
                
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 0;">ID</th>
                                <th style="width: 0;">NAMA BARANG</th>
                                <th style="width: 0;">STOK</th>
                                <th style="width: 0;">SATUAN</th>
                                <th style="">HARGA SATUAN</th>
                                <th style="width: 0;">UPDATED AT</th>
                                <th style="width: 0;">CREATED AT</th>
                                <th style="width: 0; text-align: right">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="order-id"><span class="dot"></span>#<?php echo e($ingredient->normalizedId()); ?></div>
                                    </td>
                                    <td><?php echo e($ingredient->name); ?></td>
                                    <td style="text-align: <?php echo e($hasSupply ? 'left' : 'center'); ?>">
                                        <?php echo e($ingredient->stock); ?>


                                        <?php if($ingredient->supplies->whereNull("stock_report_id")->count() > 0): ?>
                                            <span
                                                class="th-tooltip supply-tooltip"
                                                style="color: #4ade80; cursor: help;"
                                            >
                                                (+<?php echo e($ingredient->supplies->whereNull("stock_report_id")->sum("quantity")); ?>)

                                                <span class="tooltip-box">
                                                    Added from supplies
                                                </span>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($ingredient->unit_of_measurement->symbol); ?></td>
                                    <td><?php echo e(App\Support\Currency::format("IDR", $ingredient->harga_satuan)); ?>/<?php echo e($ingredient->unit_of_measurement->symbol); ?></td>
                                    <td class="date-cell" style="text-align: right"><?php echo e($ingredient->updated_at); ?></td>
                                    <td class="date-cell" style="text-align: right"><?php echo e($ingredient->created_at); ?></td>
                                    <td class="actions">
                                        <button class="icon-btn edit open-modal" title="Edit" data-modal="editModal-<?php echo e($ingredient->id); ?>">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="icon-btn delete open-modal" title="Delete" data-modal="deleteModal-<?php echo e($ingredient->id); ?>">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colSpan="9999" class="date-cell" style="text-align: center">No data.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="footer">
                    <span>Showing 3 dari 128</span>
                    <div class="pagination">
                        <button class="active">1</button>
                        <button>2</button>
                        <button>3</button>
                    </div>
                </div>
            </div>
        </div>

        <div id="addModal" class="modal">
            <div class="modal-content">

                <div class="modal-header">
                    <div class="modal-title">
                        <div class="modal-icon">
                            <i class="fa-solid fa-box"></i>
                        </div>
                        <div>
                            <h2>New Ingredient</h2>
                            <p>Add a new stock item.</p>
                        </div>
                    </div>

                    <button class="close-modal" type="button">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>

                <form method="POST" action="<?php echo e(route('stock.post')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Ingredient Name</label>
                            <input type="text" placeholder="Example: Sugar" name="name" required>
                        </div>

                        <div class="form-group">
                            <label>Stock</label>
                            <input type="number" placeholder="0" name="stock" required>
                        </div>

                        <div style="display: flex; gap: 20px">
                            <div class="form-group" style="width: 100%">
                                <label>Harga Satuan</label>
                                <input type="text" inputmode="numeric" class="currency-input" placeholder="0" name="harga_satuan" required>
                            </div>

                            <div class="form-group" style="width: 100%">
                                <label>Unit of Measurement</label>
                                <select name="unit_of_measurement_id" required>
                                    <option value="" selected disabled>-- Select Unit --</option>
    
                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->symbol); ?> (<?php echo e($unit->name); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn-secondary modal-close" type="button">Cancel</button>
                        <button class="btn-primary" type="submit">
                            <i class="fa-solid fa-floppy-disk"></i>
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="editModal-<?php echo e($ingredient->id); ?>" class="modal">
                <div class="modal-content">

                    <div class="modal-header">
                        <div class="modal-title">
                            <div class="modal-icon">
                                <i class="fa-solid fa-box"></i>
                            </div>
                            <div>
                                <h2>Edit Ingredient/Stock</h2>
                                <p>Edit #<?php echo e($ingredient->normalizedId()); ?>.</p>
                            </div>
                        </div>

                        <button class="close-modal" type="button">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <form method="POST" action="<?php echo e(route('stock.edit', ['id' => $ingredient->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Ingredient Name</label>
                                <input type="text" placeholder="Example: Sugar" name="name" value="<?php echo e($ingredient->name); ?>">
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button class="btn-secondary modal-close" type="button">Cancel</button>
                            <button class="btn-primary" type="submit">
                                <i class="fa-solid fa-floppy-disk"></i>
                                Save
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div id="deleteModal-<?php echo e($ingredient->id); ?>" class="modal">
                <div class="modal-content">

                    <div class="modal-header">
                        <div class="modal-title">
                            <div class="modal-icon">
                                <i class="fa-solid fa-box"></i>
                            </div>
                            <div>
                                <h2>Delete Ingredient/Stock</h2>
                                <p>Delete #<?php echo e($ingredient->normalizedId()); ?>.</p>
                            </div>
                        </div>

                        <button class="close-modal" type="button">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <form method="POST" action="<?php echo e(route('stock.delete', ['id' => $ingredient->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>

                        <div style="padding: 16px">
                            <p style="margin-bottom: 12px">Are you sure you wanna delete this Stock/Ingredients?</p>
    
                            <ul class="info-list">
                                <li>
                                    <span class="label">Name</span>
                                    <span class="value">Sugar</span>
                                </li>
    
                                <li>
                                    <span class="label">Current Stock</span>
                                    <span class="value">32 Gr</span>
                                </li>
    
                                <li>
                                    <span class="label">Unit</span>
                                    <span class="value">Gram</span>
                                </li>
    
                                <li>
                                    <span class="label">Last Updated</span>
                                    <span class="value">26 Sep 2026 · 09:35</span>
                                </li>
                            </ul>
                        </div>

                        <div class="modal-footer">
                            <button class="btn-secondary modal-close" type="button">Cancel</button>
                            <button class="btn-primary" type="submit">
                                <i class="fa-solid fa-floppy-disk"></i>
                                Yes, Delete it
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
    <script>
        document.querySelectorAll('.currency-input').forEach(input => {
        input.addEventListener('input', function () {
            let raw = this.value.replace(/\D/g, '');

            this.value = raw
                ? new Intl.NumberFormat('id-ID').format(Number(raw))
                : '';

            // Cari hidden input yang namanya *_raw
            const rawInput = document.getElementById(`${this.id}_raw`);

            if (rawInput) {
                rawInput.value = raw;
            }
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin.main", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ryve/Documents/Code/Muarra/muarra/resources/views/page/stock/index.blade.php ENDPATH**/ ?>