<?php $__env->startSection("content"); ?>
    <section>

        <div class="page-header">
            <div>
                <h1>Stock Report</h1>
                <p>#<?php echo e($stockReportItems->first()->stockReport->normalizedId()); ?></p>
            </div>
        </div>

        <div>
            <div class="card">

                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 0;">KODE BARANG</th>
                                <th style="width: 0;">NAMA BARANG</th>
                                <th style="width: 0;">SATUAN</th>
                                <th style="width: 0;">HARGA SATUAN</th>

                                <th style="width: 0;">
                                    STOK AWAL
                                </th>

                                <th style="width: 0;">
                                    <div class="th-tooltip">
                                        PENJUALAN

                                        <span class="tooltip-icon">
                                            <i class="fa-solid fa-circle-question"></i>
                                        </span>

                                        <span class="tooltip-box">
                                            Nilai ini otomatis terkalkulasi berdasarkan penjualan/order.
                                        </span>
                                    </div>
                                </th>

                                <th style="width: 0;">
                                    BARANG MASUK
                                </th>

                                <th style="width: 0;">
                                    <div class="th-tooltip">
                                        PERSEDIAAN AKHIR

                                        <span class="tooltip-icon">
                                            <i class="fa-solid fa-circle-question"></i>
                                        </span>

                                        <span class="tooltip-box">
                                            Nilai ini dihitung berdasarkan stok awal, penjualan, dan barang masuk.
                                        </span>
                                    </div>
                                </th>

                                <th style="width: 0; color: var(--text-primary)">
                                    STOK FISIK
                                </th>

                                <th style="width: 0;">
                                    <div class="th-tooltip">
                                        SELISIH

                                        <span class="tooltip-icon">
                                            <i class="fa-solid fa-circle-question"></i>
                                        </span>

                                        <span class="tooltip-box">
                                            Selisih antara stok fisik dan persediaan akhir.
                                        </span>
                                    </div>
                                </th>

                                <th style="width: 0; color: var(--text-primary)">
                                    SELISIH HARGA
                                </th>

                                <th>
                                    KETERANGAN
                                </th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php $__empty_1 = true; $__currentLoopData = $stockReportItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockReportItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <tr class="
                                    <?php if($stockReportItem->difference > 0): ?>
                                        row-warning
                                    <?php elseif($stockReportItem->difference < 0): ?>
                                        row-danger
                                    <?php endif; ?>
                                ">

                                    
                                    <td>
                                        <div class="order-id">

                                            <span class="dot
                                                <?php if($stockReportItem->difference > 0): ?>
                                                    dot-warning
                                                <?php elseif($stockReportItem->difference < 0): ?>
                                                    dot-danger
                                                <?php else: ?>
                                                    dot-success
                                                <?php endif; ?>
                                            "></span>

                                            #<?php echo e($stockReportItem->ingredient->normalizedId()); ?>


                                        </div>
                                    </td>

                                    
                                    <td>
                                        <?php echo e($stockReportItem->ingredient->name); ?>

                                    </td>

                                    
                                    <td style="text-align: center">
                                        <?php echo e($stockReportItem->ingredient->unit_of_measurement->symbol); ?>

                                    </td>

                                    
                                    <td style="text-align: center">
                                        <?php echo e(App\Support\Currency::format("IDR", $stockReportItem->unit_price)); ?>

                                    </td>

                                    
                                    <td style="text-align: center">
                                        <?php echo e($stockReportItem->opening_stock); ?>

                                    </td>

                                    
                                    <td style="text-align: center">
                                        <?php echo e($stockReportItem->outgoing_stock); ?>

                                    </td>

                                    
                                    <td style="text-align: center">
                                        <?php echo e($stockReportItem->incoming_stock); ?>

                                    </td>

                                    
                                    <td style="text-align: center">
                                        <?php echo e($stockReportItem->expected_stock); ?>

                                    </td>

                                    
                                    <td style="text-align: center">
                                        <?php echo e($stockReportItem->actual_stock); ?>

                                    </td>

                                    
                                    <?php if($stockReportItem->difference > 0): ?>

                                        <td style="text-align: center; color: #fbbf24">
                                            +<?php echo e($stockReportItem->difference); ?>

                                        </td>

                                    <?php elseif($stockReportItem->difference < 0): ?>

                                        <td style="text-align: center; color: #f87171">
                                            <?php echo e($stockReportItem->difference); ?>

                                        </td>

                                    <?php else: ?>

                                        <td style="text-align: center; color: #4ade80">
                                            0
                                        </td>

                                    <?php endif; ?>

                                    
                                    <?php if($stockReportItem->difference_value > 0): ?>

                                        <td style="text-align: center; color: #fbbf24">
                                            +<?php echo e(App\Support\Currency::format("IDR", $stockReportItem->difference_value)); ?>

                                        </td>

                                    <?php elseif($stockReportItem->difference_value < 0): ?>

                                        <td style="text-align: center; color: #f87171">
                                            <?php echo e(App\Support\Currency::format("IDR", $stockReportItem->difference_value)); ?>

                                        </td>

                                    <?php else: ?>

                                        <td style="text-align: center; color: #4ade80">
                                            <?php echo e(App\Support\Currency::format("IDR", 0)); ?>

                                        </td>

                                    <?php endif; ?>

                                    
                                    <?php if($stockReportItem->notes): ?>

                                        <td>
                                            <?php echo e($stockReportItem->notes); ?>

                                        </td>

                                    <?php else: ?>

                                        <td style="color: var(--text-secondary); text-align: center">
                                            -
                                        </td>

                                    <?php endif; ?>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>

            </div>

            
            <div class="stock-summary">

                <div class="stock-summary-header">
                    <div>
                        <h3>Report Summary</h3>
                        <p>Quick overview of this stock report.</p>
                    </div>

                    <?php
                        $hasShortage = $stockReportItems->contains(
                            fn ($item) => $item->difference < 0
                        );

                        $hasSurplus = $stockReportItems->contains(
                            fn ($item) => $item->difference > 0
                        );
                    ?>

                    <?php if($hasShortage): ?>
                        <span class="badge danger">
                            Shortage
                        </span>
                    <?php elseif($hasSurplus): ?>
                        <span class="badge warning">
                            Surplus
                        </span>
                    <?php else: ?>
                        <span class="badge success">
                            Matched
                        </span>
                    <?php endif; ?>

                </div>

                <div class="summary-list">

                    <?php $__empty_1 = true; $__currentLoopData = $stockReportItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockReportItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <?php if($stockReportItem->difference > 0): ?>

                            <div class="summary-item warning">
                                <span class="summary-dot"></span>

                                <span>
                                    <strong>
                                        #<?php echo e($stockReportItem->ingredient->normalizedId()); ?>

                                    </strong>

                                    <?php echo e($stockReportItem->ingredient->name); ?> is

                                    <strong class="summary-value warning">
                                        +<?php echo e($stockReportItem->difference); ?>

                                    </strong>

                                    more
                                </span>
                            </div>

                        <?php elseif($stockReportItem->difference < 0): ?>

                            <div class="summary-item danger">
                                <span class="summary-dot"></span>

                                <span>
                                    <strong>
                                        #<?php echo e($stockReportItem->ingredient->normalizedId()); ?>

                                    </strong>

                                    <?php echo e($stockReportItem->ingredient->name); ?> is

                                    <strong class="summary-value danger">
                                        <?php echo e($stockReportItem->difference); ?>

                                    </strong>

                                    less
                                </span>
                            </div>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <div class="summary-item success">
                            <span class="summary-dot"></span>

                            <span>
                                All stock matches the expected inventory.
                            </span>
                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin.main", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ryve/Documents/Code/Muarra/muarra/resources/views/page/stock/report/view.blade.php ENDPATH**/ ?>