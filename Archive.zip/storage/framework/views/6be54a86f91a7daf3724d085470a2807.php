<?php $__env->startSection("content"); ?>
    <section>
        <div class="page-header">
            <div>
                <h1>Categories</h1>
                <p>Manage all categories in one place.</p>
            </div>
            
            <button class="btn-primary">
                <i class="fa-solid fa-plus"></i>
                New Order
            </button>
        </div>
        <div>
            <div class="card">
                <div class="toolbar">
                    <div class="search">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke-width="2">
                            <circle cx="11" cy="11" r="7" />
                            <path d="m21 21-4.3-4.3" />
                        </svg>
                        <input placeholder="Im looking for...">
                    </div>
                    
                    <div class="toolbar-right">
                        <button class="btn">Export</button>
                    </div>
                </div>
                
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 0;">CATEGORY ID</th>
                                <th>NAME</th>
                                <th>SUBCATEGORIES</th>
                                <th>JML. PRODUK</th>
                                <th style="text-align: right">TANGGAL</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="order-id"><span class="dot"></span>#MCT-1024</div>
                                </td>
                                <td>Makanan</td>
                                <td>
                                    <ul style="display: flex; flex-direction: column; gap: 4px;">
                                        <li>Makanan Ringan</li>
                                        <li>Makanan Berat</li>
                                        <li>Snack</li>
                                    </ul>
                                </td>
                                <td>0</td>
                                <td class="date-cell" style="text-align: right">23 Sep 2026 · 09:12</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="order-id"><span class="dot"></span>#MCT-1024</div>
                                </td>
                                <td>Minuman</td>
                                <td>
                                    <ul style="display: flex; flex-direction: column; gap: 4px;">
                                        <li>Coffee</li>
                                        <li>Non-Coffee</li>
                                        <li>Milk</li>
                                    </ul>
                                </td>
                                <td>0</td>
                                <td class="date-cell" style="text-align: right">23 Sep 2026 · 09:12</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="footer">
                    <span>Showing 3 dari 128</span>
                    <div class="pagination">
                        <button class="active">1</button>
                        <button>2</button>
                        <button>3</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-header" style="margin-top: 28px">
            <div>
                <h1>Subcategories</h1>
                <p>Manage all categories in one place.</p>
            </div>
            
            <button class="btn-primary">
                <i class="fa-solid fa-plus"></i>
                New Order
            </button>
        </div>
        <div>
            <div class="card">
                <div class="toolbar">
                    <div class="search">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke-width="2">
                            <circle cx="11" cy="11" r="7" />
                            <path d="m21 21-4.3-4.3" />
                        </svg>
                        <input placeholder="Im looking for...">
                    </div>
                    
                    <div class="toolbar-right">
                        <button class="btn">Export</button>
                    </div>
                </div>
                
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 0;">CATEGORY ID</th>
                                <th>NAME</th>
                                <th>JML. PRODUK</th>
                                <th style="text-align: right">TANGGAL</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="order-id"><span class="dot"></span>#SCT-1024</div>
                                </td>
                                <td>Makanan Ringan</td>
                                <td>0</td>
                                <td class="date-cell" style="text-align: right">23 Sep 2026 · 09:12</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="order-id"><span class="dot"></span>#SCT-1024</div>
                                </td>
                                <td>Makanan Berat</td>
                                <td>0</td>
                                <td class="date-cell" style="text-align: right">23 Sep 2026 · 09:12</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="order-id"><span class="dot"></span>#SCT-1024</div>
                                </td>
                                <td>Snack</td>
                                <td>0</td>
                                <td class="date-cell" style="text-align: right">23 Sep 2026 · 09:12</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="order-id"><span class="dot"></span>#SCT-1024</div>
                                </td>
                                <td>Coffee</td>
                                <td>0</td>
                                <td class="date-cell" style="text-align: right">23 Sep 2026 · 09:12</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="order-id"><span class="dot"></span>#SCT-1024</div>
                                </td>
                                <td>Non-Coffee</td>
                                <td>0</td>
                                <td class="date-cell" style="text-align: right">23 Sep 2026 · 09:12</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="order-id"><span class="dot"></span>#SCT-1024</div>
                                </td>
                                <td>Milk</td>
                                <td>0</td>
                                <td class="date-cell" style="text-align: right">23 Sep 2026 · 09:12</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="footer">
                    <span>Showing 3 dari 128</span>
                    <div class="pagination">
                        <button class="active">1</button>
                        <button>2</button>
                        <button>3</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin.main", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ryve/Documents/Code/Muarra/muarra/resources/views/category.blade.php ENDPATH**/ ?>