<?php $__env->startSection("content"); ?>
    <section>
        <div class="page-header">
            <div>
                <h1>Categories</h1>
                <p>Manage all categories in one place.</p>
            </div>
            
            <button class="btn-primary open-modal" data-modal="addCategoryModal">
                <i class="fa-solid fa-plus"></i>
                New Category
            </button>
        </div>
        <div>
            <div class="card">
                <div class="toolbar">
                    <div class="search">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke-width="2">
                            <circle cx="11" cy="11" r="7" />
                            <path d="m21 21-4.3-4.3" />
                        </svg>
                        <input placeholder="Im looking for...">
                    </div>
                    
                    <div class="toolbar-right">
                        <button class="btn">Export</button>
                    </div>
                </div>
                
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 0;">CATEGORY ID</th>
                                <th style="width: 0;">NAME</th>
                                <th style="width: 0;">SUBCATEGORIES</th>
                                <th>JML. PRODUK</th>
                                <th style="width: 0;">UPDATED AT</th>
                                <th style="width: 0">CREATED_AT</th>
                                <th style="text-align: right; width: 0">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="order-id"><span class="dot"></span>#<?php echo e($category->normalizedId()); ?></div>
                                    </td>
                                    <td><?php echo e($category->name); ?></td>
                                    <td>
                                        <?php if($category->subCategories->where("deleted_at", NULL)->count() > 0): ?>
                                            <ul style="display: flex; flex-direction: column; gap: 4px;">
                                                <?php $__currentLoopData = $category->subCategories->where("deleted_at", NULL); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li style="list-style-type: none">- <?php echo e($subCategory->name); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php else: ?>
                                            <p>-</p>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($category->products->whereNull("deleted_at")->count()); ?></td>
                                    <td class="date-cell" style="text-align: right"><?php echo e($category->updated_at); ?></td>
                                    <td class="date-cell" style="text-align: right"><?php echo e($category->created_at); ?></td>
                                    <td class="actions">
                                        <button class="icon-btn edit open-modal" title="Edit" data-modal="editCategoryModal-<?php echo e($category->id); ?>">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="icon-btn delete open-modal" title="Delete" data-modal="deleteCategoryModal-<?php echo e($category->id); ?>">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colSpan="9999" class="date-cell" style="text-align: center">No data.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="footer">
                    <span>Showing 3 dari 128</span>
                    <div class="pagination">
                        <button class="active">1</button>
                        <button>2</button>
                        <button>3</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-header" style="margin-top: 28px">
            <div>
                <h1>Subcategories</h1>
                <p>Manage all categories in one place.</p>
            </div>
            
            <button class="btn-primary open-modal" data-modal="addSubcategoryModal">
                <i class="fa-solid fa-plus"></i>
                New Subcategory
            </button>
        </div>
        <div>
            <div class="card">
                <div class="toolbar">
                    <div class="search">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke-width="2">
                            <circle cx="11" cy="11" r="7" />
                            <path d="m21 21-4.3-4.3" />
                        </svg>
                        <input placeholder="Im looking for...">
                    </div>
                    
                    <div class="toolbar-right">
                        <button class="btn">Export</button>
                    </div>
                </div>
                
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 0;">CATEGORY ID</th>
                                <th style="width: 0;">NAME</th>
                                <th>JML. PRODUK</th>
                                <th style="width: 0;">UPDATED AT</th>
                                <th style="width: 0">CREATED_AT</th>
                                <th style="text-align: right; width: 0">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="order-id"><span class="dot"></span>#<?php echo e($subCategory->normalizedId()); ?></div>
                                    </td>
                                    <td><?php echo e($subCategory->name); ?></td>
                                    <td><?php echo e($subCategory->products->whereNull("deleted_at")->count()); ?></td>
                                    <td class="date-cell" style="text-align: right"><?php echo e($subCategory->updated_at); ?></td>
                                    <td class="date-cell" style="text-align: right"><?php echo e($subCategory->created_at); ?></td>
                                    <td class="actions">
                                        <button class="icon-btn edit open-modal" title="Edit" data-modal="editSubCategoryModal-<?php echo e($subCategory->id); ?>">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="icon-btn delete open-modal" title="Delete" data-modal="deleteSubCategoryModal-<?php echo e($subCategory->id); ?>">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colSpan="9999" class="date-cell" style="text-align: center">No data.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="footer">
                    <span>Showing 3 dari 128</span>
                    <div class="pagination">
                        <button class="active">1</button>
                        <button>2</button>
                        <button>3</button>
                    </div>
                </div>
            </div>
        </div>

        <div id="addCategoryModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title">
                        <div class="modal-icon">
                            <i class="fa-solid fa-box"></i>
                        </div>
                        <div>
                            <h2>New Category</h2>
                            <p>Add a new category.</p>
                        </div>
                    </div>

                    <button class="close-modal" type="button">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>

                <form method="POST" action="<?php echo e(route('category.post')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Category Name</label>
                            <input type="text" placeholder="Example: Sugar" name="name">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn-secondary modal-close" type="button">Cancel</button>
                        <button class="btn-primary" type="submit">
                            <i class="fa-solid fa-floppy-disk"></i>
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="editCategoryModal-<?php echo e($category->id); ?>" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-title">
                            <div class="modal-icon">
                                <i class="fa-solid fa-box"></i>
                            </div>
                            <div>
                                <h2>Edit Category</h2>
                                <p>Edit #<?php echo e($category->normalizedId()); ?>.</p>
                            </div>
                        </div>

                        <button class="close-modal" type="button">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <form method="POST" action="<?php echo e(route('category.edit', ['id' => $category->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Category Name</label>
                                <input type="text" placeholder="Example: Sugar" name="name" value="<?php echo e($category->name); ?>">
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button class="btn-secondary modal-close" type="button">Cancel</button>
                            <button class="btn-primary" type="submit">
                                <i class="fa-solid fa-floppy-disk"></i>
                                Save
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div id="deleteCategoryModal-<?php echo e($category->id); ?>" class="modal">
                <div class="modal-content">

                    <div class="modal-header">
                        <div class="modal-title">
                            <div class="modal-icon">
                                <i class="fa-solid fa-box"></i>
                            </div>
                            <div>
                                <h2>Delete Category</h2>
                                <p>Delete #<?php echo e($category->normalizedId()); ?>.</p>
                            </div>
                        </div>

                        <button class="close-modal" type="button">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <form method="POST" action="<?php echo e(route('category.delete', ['id' => $category->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>

                        <div style="padding: 16px">
                            <p style="margin-bottom: 12px">Are you sure you wanna delete this category?</p>
    
                            <ul class="info-list">
                                <li>
                                    <span class="label">Name</span>
                                    <span class="value"><?php echo e($category->name); ?></span>
                                </li>
    
                                <li>
                                    <span class="label">Jml. Produk</span>
                                    <span class="value">0</span>
                                </li>
    
                                <li>
                                    <span class="label">Subcategories</span>
                                    <span class="value">
                                        <ul>
                                            <?php $__currentLoopData = $category->subCategories->where("deleted_at", NULL); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li style="padding: 0">- <?php echo e($subCategory->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </span>
                                </li>
    
                                <li>
                                    <span class="label">Last Updated</span>
                                    <span class="value"><?php echo e($category->updated_at); ?></span>
                                </li>

                                <li>
                                    <span class="label">Created At</span>
                                    <span class="value"><?php echo e($category->created_at); ?></span>
                                </li>
                            </ul>
                        </div>

                        <div class="modal-footer">
                            <button class="btn-secondary modal-close" type="button">Cancel</button>
                            <button class="btn-primary" type="submit">
                                <i class="fa-solid fa-floppy-disk"></i>
                                Yes, Delete it
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div id="addSubcategoryModal" class="modal">
            <div class="modal-content">

                <div class="modal-header">
                    <div class="modal-title">
                        <div class="modal-icon">
                            <i class="fa-solid fa-box"></i>
                        </div>
                        <div>
                            <h2>New Subcategory</h2>
                            <p>Add a new subcateogry.</p>
                        </div>
                    </div>

                    <button class="close-modal" type="button">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>

                <form method="POST" action="<?php echo e(route('category.sub.post')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Category</label>
                            <select name="product_category_id" required>
                                <option value="" selected disabled>-- Select Category --</option>
                                
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Subcategory Name</label>
                            <input type="text" placeholder="Example: Sugar" name="name" required>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn-secondary modal-close" type="button">Cancel</button>
                        <button class="btn-primary" type="submit">
                            <i class="fa-solid fa-floppy-disk"></i>
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="editSubCategoryModal-<?php echo e($subCategory->id); ?>" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-title">
                            <div class="modal-icon">
                                <i class="fa-solid fa-box"></i>
                            </div>
                            <div>
                                <h2>Edit Subcategory</h2>
                                <p>Edit #<?php echo e($subCategory->normalizedId()); ?>.</p>
                            </div>
                        </div>

                        <button class="close-modal" type="button">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <form method="POST" action="<?php echo e(route('category.sub.edit', ['id' => $subCategory->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Category</label>
                                <select name="product_category_id" required>
                                    <?php if($subCategory->category->deleted_at): ?>
                                        <option value="<?php echo e($subCategory->product_category_id); ?>" selected disabled><?php echo e($subCategory->category->name); ?> (DELETED)</option>
                                    <?php endif; ?>

                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php if($subCategory->product_category_id == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Subcategory Name</label>
                                <input type="text" placeholder="Example: Sugar" name="name" value="<?php echo e($subCategory->name); ?>">
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button class="btn-secondary modal-close" type="button">Cancel</button>
                            <button class="btn-primary" type="submit">
                                <i class="fa-solid fa-floppy-disk"></i>
                                Save
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div id="deleteSubCategoryModal-<?php echo e($subCategory->id); ?>" class="modal">
                <div class="modal-content">

                    <div class="modal-header">
                        <div class="modal-title">
                            <div class="modal-icon">
                                <i class="fa-solid fa-box"></i>
                            </div>
                            <div>
                                <h2>Delete SubCategory</h2>
                                <p>Delete #<?php echo e($subCategory->normalizedId()); ?>.</p>
                            </div>
                        </div>

                        <button class="close-modal" type="button">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <form method="POST" action="<?php echo e(route('category.sub.delete', ['id' => $subCategory->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>

                        <div style="padding: 16px">
                            <p style="margin-bottom: 12px">Are you sure you wanna delete this category?</p>
    
                            <ul class="info-list">
                                <li>
                                    <span class="label">Name</span>
                                    <span class="value"><?php echo e($subCategory->name); ?></span>
                                </li>
    
                                <li>
                                    <span class="label">Category</span>
                                    <span class="value"><?php echo e($subCategory->category->name); ?></span>
                                </li>
                            </ul>
                        </div>

                        <div class="modal-footer">
                            <button class="btn-secondary modal-close" type="button">Cancel</button>
                            <button class="btn-primary" type="submit">
                                <i class="fa-solid fa-floppy-disk"></i>
                                Yes, Delete it
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin.main", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ryve/Documents/Code/Muarra/muarra/resources/views/page/category/index.blade.php ENDPATH**/ ?>