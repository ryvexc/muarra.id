<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Muarra Back Office</title>
    


    <link rel="stylesheet" href="<?php echo e(asset('assets/css/muarra-dark.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/core.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.3.1/css/all.css">
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
  <div class="layout">
    <button class="sidebar-toggle" id="sidebarToggle">
        <i class="fa-solid fa-bars"></i>
    </button>

    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <?php echo $__env->make("layout.admin.sidebar", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  
    <?php echo $__env->yieldContent("content"); ?>
  </div>

  <script>
    const openButtons = document.querySelectorAll(".open-modal");

    openButtons.forEach(btn=>{
        btn.addEventListener("click",()=>{
            const modal=document.getElementById(btn.dataset.modal);
            modal.classList.add("active");
        });
    });

    document.querySelectorAll(".modal-close, .close-modal").forEach(btn => {
        btn.addEventListener("click", () => {
            btn.closest(".modal").classList.remove("active");
        });
    });

    document.querySelectorAll(".modal").forEach(modal=>{
        modal.addEventListener("click",(e)=>{
            if(e.target===modal){
                modal.classList.remove("active");
            }
        });
    });

    document.addEventListener("keydown",(e)=>{
        if(e.key==="Escape"){
            document.querySelectorAll(".modal.active").forEach(m=>{
                m.classList.remove("active");
            });
        }
    });
  </script>

  <script>
    const sidebar = document.getElementById("sidebar");
    const overlay = document.getElementById("sidebarOverlay");
    const toggle = document.getElementById("sidebarToggle");

    toggle.addEventListener("click", () => {
        sidebar.classList.toggle("open");
        overlay.classList.toggle("active");
    });

    overlay.addEventListener("click", () => {
        sidebar.classList.remove("open");
        overlay.classList.remove("active");
    });

    window.addEventListener("resize", () => {
        if(window.innerWidth > 768){
            sidebar.classList.remove("open");
            overlay.classList.remove("active");
        }
    });
    </script>

  <?php echo $__env->yieldContent("script"); ?>
</body>

</html><?php /**PATH /Users/ryve/Documents/Code/Muarra/muarra/resources/views/layout/admin/main.blade.php ENDPATH**/ ?>