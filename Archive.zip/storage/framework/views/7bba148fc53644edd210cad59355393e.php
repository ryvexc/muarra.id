<?php $__env->startSection("content"); ?>
    <section>
        <div class="page-header">
            <div>
                <h1>Page is Disabled</h1>
                <p>This page is currently disabled.</p>
            </div>
            
            
        </div>
        <div>
            
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin.main", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ryve/Documents/Code/Muarra/muarra/resources/views/page/maintenance/disabled.blade.php ENDPATH**/ ?>