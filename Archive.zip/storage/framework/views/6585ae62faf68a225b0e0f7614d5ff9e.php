<?php $__env->startSection("content"); ?>
    <section>
        <div class="page-header">
            <div>
                <h1>Products</h1>
                <p>Manage all products in one place.</p>
            </div>
            
            <button class="btn-primary">
                <i class="fa-solid fa-plus"></i>
                New Product
            </button>
        </div>
        <div>
            <div class="card">
                <div class="toolbar">
                    <div class="search">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke-width="2">
                            <circle cx="11" cy="11" r="7" />
                            <path d="m21 21-4.3-4.3" />
                        </svg>
                        <input placeholder="Im looking for...">
                    </div>
                    
                    <div class="toolbar-right">
                        <button class="btn">Export</button>
                    </div>
                </div>
                
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 0;">PRODUCT ID</th>
                                <th>NAME</th>
                                <th>CATEGORY</th>
                                <th>SUBCATEGORY</th>
                                <th>STOK</th>
                                <th>HARGA JUAL</th>
                                <th>HARGA MODAL</th>
                                <th style="text-align: right">TANGGAL</th>
                                <th style="text-align: right">ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="order-id"><span class="dot"></span>#PRD-1024</div>
                                </td>
                                <td>Burger Bangor 1</td>
                                <td>Makanan</td>
                                <td>Makanan Ringan</td>
                                <td>0</td>
                                <td>Rp20.000</td>
                                <td>Rp12.000</td>
                                <td class="date-cell" style="text-align: right">23 Sep 2026 · 09:12</td>
                                <td class="actions">
                                    <button class="icon-btn edit" title="Edit">
                                        <i class="fa-solid fa-pen"></i>
                                    </button>

                                    <button class="icon-btn delete" title="Delete">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="footer">
                    <span>Showing 3 dari 128</span>
                    <div class="pagination">
                        <button class="active">1</button>
                        <button>2</button>
                        <button>3</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin.main", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ryve/Documents/Code/Muarra/muarra/resources/views/products.blade.php ENDPATH**/ ?>